function updateProgress(element, width) {
    const progressBar = element.querySelector('.progress');
    progressBar.style.width = `${width}%`;
}
